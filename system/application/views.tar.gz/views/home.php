<div>
    <form id="add_post_form" action="<?php echo site_url('post/add'); ?>" method="post">
        <div><textarea name="message"></textarea></div>
        <div><input type="submit" name="submit" value="Generate" /></div>
    </form>
</div>