<div id="footer">
</div>
<div class="clear"></div>
<div>&copy; <a href="http://randell.ph/">Randell.ph</a> - MMDA Sign Post Generator</div>