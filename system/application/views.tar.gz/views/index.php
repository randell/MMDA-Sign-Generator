<?php echo $this->load->view('login'); ?>

<a href="<?php echo site_url('signup'); ?>">Register</a>